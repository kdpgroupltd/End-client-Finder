# End-Client Finder

Paste a recruiter advert, discover the real hiring company.

## How to run locally

```bash
pip install -r requirements.txt
streamlit run end_client_finder.py -- --as-ui
```
