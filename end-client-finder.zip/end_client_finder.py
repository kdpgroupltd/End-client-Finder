#!/usr/bin/env python3
# End-Client Finder robust version (full code goes here)
# For brevity, copy from the provided canvas content in ChatGPT.
print("This is a placeholder. Replace with the robust code from the canvas.")
